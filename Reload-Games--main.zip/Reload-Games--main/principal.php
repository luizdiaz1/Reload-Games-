<?php
require 'config.php';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if ($q) {
    // Primeiro tenta buscar exato pelo nome (ignora maiúsculas/minúsculas)
    $stmt = $mysqli->prepare("SELECT * FROM jogos WHERE LOWER(nome) = LOWER(?) ORDER BY criado_em DESC");
    $stmt->bind_param('s', $q);
    $stmt->execute();
    $res = $stmt->get_result();

    // Se não encontrou nenhum resultado exato, faz a busca parcial
    if ($res->num_rows === 0) {
        $like = "%{$q}%";
        $stmt = $mysqli->prepare("SELECT * FROM jogos WHERE nome LIKE ? OR genero LIKE ? OR plataforma LIKE ? ORDER BY criado_em DESC");
        $stmt->bind_param('sss', $like, $like, $like);
        $stmt->execute();
        $res = $stmt->get_result();
    }
} else {
    $stmt = $mysqli->prepare("SELECT * FROM jogos ORDER BY criado_em DESC");
    $stmt->execute();
    $res = $stmt->get_result();
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Reload Games</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>🎮 Reload Games</h1>

  <div style="display:flex;justify-content:space-between;align-items:center;">
    <form method="get" class="search">
      <input type="text" name="q" placeholder="Pesquisar por nome, gênero ou plataforma" value="<?php echo htmlspecialchars($q); ?>">
      <button class="btn">Buscar</button>
    </form>
    <a href="addnovojogo.php" class="btn">+ Novo Jogo</a>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>Nome</th><th>Gênero</th><th>Plataforma</th><th>Preço</th><th>Descrição</th><th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['nome']); ?></td>
          <td><?php echo htmlspecialchars($row['genero']); ?></td>
          <td><?php echo htmlspecialchars($row['plataforma']); ?></td>
          <td>R$ <?php echo number_format($row['preco'],2,',','.'); ?></td>
          <td><?php echo htmlspecialchars(mb_strimwidth($row['descricao'],0,80,'...')); ?></td>
          <td class="actions">
            <a href="editarnovojogo.php?id=<?php echo $row['id']; ?>">Editar</a>
            <a href="deletarjogo.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Excluir este jogo?')">Excluir</a>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if ($res->num_rows === 0): ?>
        <tr><td colspan="6"><em>Nenhum jogo encontrado.</em></td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>

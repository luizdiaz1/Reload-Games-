<?php
require 'config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = $mysqli->prepare("SELECT * FROM jogos WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$game = $stmt->get_result()->fetch_assoc();
if (!$game) { header("Location: principal.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $genero = trim($_POST['genero']);
    $plataforma = trim($_POST['plataforma']);
    $preco = $_POST['preco'];
    $descricao = trim($_POST['descricao']);

    $stmt = $mysqli->prepare("UPDATE jogos SET nome=?, genero=?, plataforma=?, preco=?, descricao=? WHERE id=?");
    $stmt->bind_param('sssddi', $nome, $genero, $plataforma, $preco, $descricao, $id);
    $stmt->execute();
    header("Location: principal.php");
    exit;
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Editar jogo — Reload Games</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Editar Jogo</h1>
  <form method="post">
    <div class="form-row"><label>Nome:</label><input type="text" name="nome" value="<?php echo htmlspecialchars($game['nome']); ?>" required></div>
    <div class="form-row"><label>Gênero:</label><input type="text" name="genero" value="<?php echo htmlspecialchars($game['genero']); ?>"></div>
    <div class="form-row"><label>Plataforma:</label>
      <select name="plataforma">
        <?php foreach (['PC','PlayStation','Xbox','Nintendo','Mobile'] as $p): ?>
          <option value="<?php echo $p; ?>" <?php if($p==$game['plataforma']) echo 'selected'; ?>><?php echo $p; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-row"><label>Preço:</label><input type="number" step="0.01" name="preco" value="<?php echo htmlspecialchars($game['preco']); ?>"></div>
    <div class="form-row"><label>Descrição:</label><textarea name="descricao" rows="4"><?php echo htmlspecialchars($game['descricao']); ?></textarea></div>
    <button class="btn">Salvar</button> <a href="principal.php">Voltar</a>
  </form>
</div>
</body>
</html>

<?php
require 'config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $genero = trim($_POST['genero']);
    $plataforma = trim($_POST['plataforma']);
    $preco = $_POST['preco'];
    $descricao = trim($_POST['descricao']);

    if ($nome === '') $errors[] = "O nome é obrigatório.";

    if (!$errors) {
        $stmt = $mysqli->prepare("INSERT INTO jogos (nome, genero, plataforma, preco, descricao) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssds', $nome, $genero, $plataforma, $preco, $descricao);
        $stmt->execute();
        header("Location: principal.php");
        exit;
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Novo Jogo — Reload Games</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Adicionar Novo Jogo</h1>

  <?php foreach ($errors as $e): ?>
    <p style="color:red"><?= htmlspecialchars($e) ?></p>
  <?php endforeach; ?>

  <form method="post">
    <div class="form-row">
      <label>Nome:</label>
      <input type="text" name="nome" required>
    </div>

    <div class="form-row">
      <label>Gênero:</label>
      <input type="text" name="genero">
    </div>

    <div class="form-row">
      <label>Plataforma:</label>
      <select name="plataforma">
        <option value="PC">PC</option>
        <option value="PlayStation">PlayStation</option>
        <option value="Xbox">Xbox</option>
        <option value="Nintendo">Nintendo</option>
        <option value="Mobile">Mobile</option>
      </select>
    </div>

    <div class="form-row">
      <label>Preço:</label>
      <input type="number" step="0.01" name="preco">
    </div>

    <div class="form-row">
      <label>Descrição:</label>
      <textarea name="descricao" rows="4"></textarea>
    </div>

    <button class="btn">Salvar</button>
    <a href="principal.php">Voltar</a>
  </form>
</div>
</body>
</html>
